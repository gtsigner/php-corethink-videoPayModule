<?php
/**
 * Created by PhpStorm.
 * User: ZhaoJun
 * Date: 2016/2/17
 * Time: 23:51
 */

namespace Video\Admin;


use Admin\Controller\AdminController;
use Common\Builder\FormBuilder;

class VideoAdmin extends AdminController
{


    public function add()
    {

        $builder = new FormBuilder();
        $builder->display();
    }
}