
CREATE TABLE `oc_video_pay_logs` (
  `order_no` varchar(50) NOT NULL DEFAULT '' COMMENT '订单号',
  `uid` int(10) unsigned DEFAULT '0' COMMENT '会员id',
  `video_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '视频id',
  `pay_money` decimal(10,2) unsigned DEFAULT NULL COMMENT '支付金额',
  `create_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`order_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='默认数据表';

CREATE TABLE `oc_video_index` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(127) NOT NULL DEFAULT '' COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `pay_money` decimal(10,2) unsigned DEFAULT NULL COMMENT '支付金额',
  `free_time` int(10) DEFAULT '18' COMMENT '免费时长,秒',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `mark` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `video_path` varchar(255) DEFAULT NULL COMMENT '视频路径',
  `video_name` varchar(255) DEFAULT NULL COMMENT '视频名称',
  `logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='默认数据表';

CREATE TABLE `oc_video_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父分类ID',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '分类名称',
  `icon` varchar(32) NOT NULL DEFAULT '' COMMENT '缩略图',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='栏目分类表';
