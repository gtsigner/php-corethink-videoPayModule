DROP TABLE IF EXISTS `oc_video_pay_logs`;
DROP TABLE IF EXISTS `oc_video_index`;
DROP TABLE IF EXISTS `oc_video_category`;
